import { Component } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { CommentService } from "./comment.service";

@Component({
  selector: 'comment-crud',
  templateUrl: './comment.component.html',
  standalone: true,
  imports: [CommonModule, FormsModule],
  providers: [CommentService]
})
export class CommentComponent {
  comment: any = {
    commentId: 0,
    text: "",
    createdAt: "",
    user: { userId: null },
    task: { taskId: null },
  };
  commentList: any = [];
  currentAction: string | null = null;

  constructor(private commentService: CommentService) { }

  public createNewComment() {
    if (!this.comment.user.userId || !this.comment.task.taskId) {
      console.error("User ID and Task ID are required.");
      return;
    }
    this.commentService.createNewComment(this.comment).subscribe(() => {
      console.log("Comment created successfully.");
      this.clearForm();
    });
  }

  public getListOfComments() {
    this.commentService.getListOfComments().subscribe(data => this.commentList = data);
    this.clearForm();
  }

public getCommentByCommentId() {
    if (this.comment.commentId == null || this.comment.commentId === 0) {
      console.error("Comment ID is required.");
      return;
    }
  
    this.commentService.getCommentByCommentId(this.comment.commentId).subscribe(
      data => {
        if (data) {
          this.comment = data;  
          console.log("Comment fetched:", this.comment);
        } else {
          console.log("No comment found with ID", this.comment.commentId);
          
          this.clearForm(); 
        }
      },
      error => {
        console.error('Error fetching comment:', error);
     
      }
    );
  }
  
  public updateCommentDetails() {
    this.commentService.updateCommentDetails(this.comment).subscribe();
  }

  public deleteComment() {
    this.commentService.deleteComment(this.comment.commentId).subscribe();
  }

  clearForm() {
    this.comment = {
      commentId: 0,
      text: "",
      createdAt: "",
      user: { userId: null },
      task: { taskId: null },
    };
  }

  setAction(action: string) {
    this.currentAction = action;
    this.clearForm();
  }

  // Determine which fields to show based on the action
  showField(field: string): boolean {
    if (!this.currentAction) {
      return false; // or true, depending on your preference for the default behavior
    }

    const fieldsForActions: Record<string, string[]> = {
      create: ["commentId", "text", "createdAt", "userId", "taskId"],
      update: ["commentId", "text", "createdAt", "userId", "taskId"],
      getById: ["commentId"],
      delete: ["commentId"],
    };

    return fieldsForActions[this.currentAction]?.includes(field) ?? false; // Use nullish coalescing to default to false
  }

  // Handle form submission based on the current action
  handleAction() {
    switch (this.currentAction) {
      case "create":
        this.createNewComment();
        break;
      case "update":
        this.updateCommentDetails();
        break;
      case "getById":
        this.getCommentByCommentId();
        break;
      case "delete":
        this.deleteComment();
        break;
    }
    this.clearForm();
    this.currentAction = null;
  }
}

