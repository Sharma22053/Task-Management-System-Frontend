import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Task , TaskProjection } from '../../models/task.model';

@Injectable({
  providedIn: 'root',
})
export class TaskService {
  private baseUrl = 'http://localhost:8091/api/tasks';

  constructor(private http: HttpClient) {}

  createTask(task: Task): Observable<any> {
    return this.http.post(`${this.baseUrl}/post`, task);
  }

  getOverdueTasks(): Observable<TaskProjection[]> {
    return this.http.get<TaskProjection[]>(`${this.baseUrl}/overdue`);
  }

  getTasksDueSoon(): Observable<TaskProjection[]> {
    return this.http.get<TaskProjection[]>(`${this.baseUrl}/due-soon`);
  }

  getTasksByPriorityAndStatus(priority: string, status: string): Observable<TaskProjection[]> {
    return this.http.get<TaskProjection[]>(
      `${this.baseUrl}/priority/${priority}/status/${status}`
    );
  }

  getTasksByUserIdAndStatus(userId: number, status: string): Observable<TaskProjection[]> {
    return this.http.get<TaskProjection[]>(
      `${this.baseUrl}/user/${userId}/status/${status}`
    );
  }

  getTasksByCategoryId(categoryId: number): Observable<TaskProjection[]> {
    return this.http.get<TaskProjection[]>(this.baseUrl + "/category/" + categoryId);
  }

  updateTask(taskId: number, task: Task): Observable<any> {
    return this.http.put(`${this.baseUrl}/update/${taskId}`, task);
  }

  deleteTask(taskId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${taskId}`);
  }
}
