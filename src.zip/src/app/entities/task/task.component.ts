import { Component, OnInit } from '@angular/core';
import { TaskService } from './task.service';
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { Task , TaskProjection } from '../../models/task.model';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  standalone: true,
  imports: [CommonModule, FormsModule],
  providers: [TaskService]
})
export class TaskComponent {
  tasks: TaskProjection[] = [];
  task: Task = {
    taskId: 0,
    taskName: '',
    description: '',
    dueDate: '',
    priority: '',
    status: '',
    project: { projectId: 0 },
    user: { userId: 0 },
  };
  message: string = '';
  selectedAction: string = '';
status: string = '';
priority: string = '';
userId: number = 0;
categoryId: number = 0;
taskId: number = 0;

  constructor(private taskService: TaskService) {}

  getTasksDueSoon(): void {
    this.taskService.getTasksDueSoon().subscribe(
      (tasks) => (this.tasks = tasks),
      (error) => console.error(error)
    );
  }

  getOverdueTasks(): void {
    this.taskService.getOverdueTasks().subscribe(
      (tasks) => (this.tasks = tasks),
      (error) => console.error(error)
    );
  }

  getTasksByPriorityAndStatus(priority: string, status: string): void {
    this.taskService.getTasksByPriorityAndStatus(priority, status).subscribe(
      (tasks) => (this.tasks = tasks),
      (error) => console.error(error)
    );
  }

  createTask(): void {
    this.taskService.createTask(this.task).subscribe(
      (response) => (this.message = 'Task created successfully!'),
      (error) => console.error(error)
    );
  }

  updateTask(taskId: number): void {
    this.taskService.updateTask(taskId, this.task).subscribe(
      (response) => (this.message = 'Task updated successfully!'),
      (error) => console.error(error)
    );
  }

  deleteTask(taskId: number): void {
    this.taskService.deleteTask(taskId).subscribe(
      (response) => (this.message = 'Task deleted successfully!'),
      (error) => console.error(error)
    );
  }

  getTasksByUserIdAndStatus(userId: number, status: string): void {
    this.taskService.getTasksByUserIdAndStatus(userId, status).subscribe(
      (tasks) => (this.tasks = tasks),
      (error) => console.error(error)
    );
  }

  getTasksByCategory(categoryId: number): void {
    this.taskService.getTasksByCategoryId(categoryId).subscribe(
      (tasks) => (this.tasks = tasks),
      (error) => console.error(error)
    );
  }

  onFormSubmit(): void {
    switch (this.selectedAction) {
      case 'create':
        this.createTask();
        break;
      case 'update':
        this.updateTask(this.task.taskId);
        break;
      case 'delete':
        this.deleteTask(this.task.taskId);
        break;
      case 'getByPriorityAndStatus':
        this.getTasksByPriorityAndStatus(this.priority, this.status);
        break;
      case 'getByUserAndStatus':
        this.getTasksByUserIdAndStatus(this.userId, this.status);
        break;
      case 'getByCategory':
        this.getTasksByCategory(this.categoryId);
        break;
      case 'getDueSoon':
        this.getTasksDueSoon();
        break;
      case 'getOverdue':
        this.getOverdueTasks();
        break;
      default:
        console.error('Invalid action');
    }
  }
  
  isSubmitDisabled(): boolean {
    if (this.selectedAction === 'create' || this.selectedAction === 'update') {
      return !this.task.taskId || !this.task.taskName || !this.task.dueDate || !this.task.priority || !this.task.status;
    } else if (this.selectedAction === 'delete') {
    //   return !this.taskId;
        return !this.task.taskId || this.task.taskId <= 0;
    } else {
      return false; // Other actions don't need this validation
    }
  }

  selectAction(action: string): void {
    this.selectedAction = action;
    this.message = ''; // Reset any previous message
    if (action === 'create' || action === 'update') {
      this.task = {
        taskId: 0,
        taskName: '',
        description: '',
        dueDate: '',
        priority: '',
        status: '',
        project: { projectId: 0 },
        user: { userId: 0 },
      };
    } else if (action === 'delete') {
      this.taskId = 0;
    }
  }
  
}
