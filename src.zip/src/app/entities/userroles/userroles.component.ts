import { Component, OnInit } from '@angular/core';
import { UserRolesService } from './userroles.service';
import { UserRoles } from '../../models/userroles.model';
import { UserRoleProjection } from '../../models/userrole.model';
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";

@Component({
  selector: 'app-userroles',
  templateUrl: './userroles.component.html',
  standalone: true,
  imports: [CommonModule, FormsModule],
  providers: [UserRolesService]
})
export class UserRolesComponent {
  userRoles: UserRoleProjection[] = [];
  newUserRole: UserRoles = {
    id: {
      userId: 0,
      userRoleId: 0,
    },
    userRolesId: {
      userRoleId: 0,
      roleName: '',
    },
  };
  successMessage = '';
  errorMessage = '';
  userIdForRoles = 0; // For "Get User Roles by User ID"
  revokeUserRoleId = 0; // For "Revoke User Role"
  revokeUserId = 0;

  isAssignFormVisible = false;
  isGetUserRolesFormVisible = false;
  isRevokeFormVisible = false;

  constructor(private userRolesService: UserRolesService) {}

  // Fetch all user roles
  fetchAllUserRoles(): void {
    this.userRolesService.getAllUserRoles().subscribe({
      next: (data) => (this.userRoles = data),
      error: (err) => (this.errorMessage = 'Failed to load user roles.'),
    });
  }

  // Assign a new user role
  assignUserRole(): void {
    this.userRolesService.assignUserRole(this.newUserRole).subscribe({
      next: (response) => {
        
        this.fetchAllUserRoles();
      },
      error: (err) => (this.errorMessage = 'Failed to assign user role.'),
    });
  }

  // Revoke a user role
  revokeUserRole(userRoleId: number, userId: number): void {
    this.userRolesService.revokeUserRole(userRoleId, userId).subscribe({
      next: (response) => {
        
        this.fetchAllUserRoles();
      },
      error: (err) => (this.errorMessage = 'Failed to revoke user role.'),
    });
  }

  getUserRolesByUserId(): void {
    if (!this.userIdForRoles) {
      this.errorMessage = 'Please provide a valid User ID.';
      return;
    }

    this.userRolesService.getUserRolesByUserId(this.userIdForRoles).subscribe({
      next: (data) => {
        this.userRoles = data;
        this.successMessage = `User roles fetched successfully for User ID: ${this.userIdForRoles}`;
        this.errorMessage = '';
      },
      error: (err) => {
        this.errorMessage = 'Failed to fetch user roles.';
        this.successMessage = '';
      },
    });
  }

  showAssignForm(): void {
    this.resetForms();
    this.isAssignFormVisible = true;
  }

  showGetUserRolesForm(): void {
    this.resetForms();
    this.isGetUserRolesFormVisible = true;
  }

  showRevokeForm(): void {
    this.resetForms();
    this.isRevokeFormVisible = true;
  }

  // Reset all form visibility flags
  resetForms(): void {
    this.isAssignFormVisible = false;
    this.isGetUserRolesFormVisible = false;
    this.isRevokeFormVisible = false;
  }
}
