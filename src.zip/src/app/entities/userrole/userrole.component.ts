 import { Component } from '@angular/core';
import { UserRoleService } from './userrole.service';  // Ensure the service is correctly imported
import { FormsModule , } from "@angular/forms";
import { CommonModule } from "@angular/common";
 
 
@Component({
  selector: 'userrole-crud',
  templateUrl: './userrole.component.html',
  imports: [CommonModule, FormsModule]
})
export class UserRoleComponent {
  userRole: any = { userRoleId: 0, roleName: '' };  // Removed roleDescription
  userRoleList: any[] = [];
  loading: boolean = false;
  loadingMessage: string = '';
  currentAction: string = '';
 
  constructor(private userRoleService: UserRoleService) {}

 
  // Create New User Role
  createNewUserRole(): void {
    if (this.userRole.roleName) {  // Check if roleName is provided
      this.loading = true;
      this.loadingMessage = 'Creating user role...';
 
      this.userRoleService.createUserRole(this.userRole).subscribe(
        (response) => {
          console.log('User Role created:', response);
          this.clearForm();
          this.getAllUserRoles(); // Refresh the list
          this.loading = false;
        },
        (error) => {
          console.error('Error creating user role:', error);
          alert(`Error: ${error.message || error}`);
          this.loading = false;
        }
      );
    } else {
      alert('Please fill in all fields.');
    }
  }
 
  // Update User Role
  updateUserRoleDetails(): void {
    if (this.userRole.userRoleId && this.userRole.roleName) {
      this.loading = true;
      this.loadingMessage = 'Updating user role...';
 
      this.userRoleService.updateUserRole(this.userRole).subscribe(
        (response) => {
          console.log('User Role updated:', response);
          this.clearForm();
          this.getAllUserRoles(); // Refresh the list
          this.loading = false;
        },
        (error) => {
          console.error('Error updating user role:', error);
          alert(`Error: ${error.message || error}`);
          this.loading = false;
        }
      );
    } else {
      alert('Invalid User Role ID or Role Name.');
    }
  }
 
  // Delete User Role
  deleteUserRoleById(userRoleId: number): void {
    if (userRoleId > 0) {
      this.loading = true;
      this.loadingMessage = 'Deleting user role...';
 
      this.userRoleService.deleteUserRole(userRoleId).subscribe(
        (response) => {
          console.log('User Role deleted:', response);
          this.getAllUserRoles(); // Refresh the list
          this.loading = false;
          this.clearForm();
        },
        (error) => {
          console.error('Error deleting user role:', error);
          alert(`Error: ${error.message || error}`);
          this.loading = false;
        }
      );
    } else {
      alert('Please enter a valid User Role ID.');
    }
  }
 
  // Get All User Roles
  getAllUserRoles(): void {
    this.loading = true;
    this.loadingMessage = 'Fetching all user roles...';
 
    this.userRoleService.getAllUserRoles().subscribe(
      (data) => {
        this.userRoleList = data;
        this.loading = false;
      },
      (error) => {
        console.error('Error fetching all user roles:', error);
        alert(`Error: ${error.message || error}`);
        this.loading = false;
      }
    );
  }
 
  // Get User Role by ID
  getUserRoleById(userRoleId: number): void {
    if (userRoleId > 0) {
      this.loading = true;
      this.loadingMessage = 'Fetching user role details...';
 
      this.userRoleService.getUserRoleById(userRoleId).subscribe(
        (data) => {
          this.userRole = data;
          this.loading = false;
        },
        (error) => {
          console.error('Error fetching user role by ID:', error);
          alert(`Error: ${error.message || error}`);
          this.loading = false;
        }
      );
    } else {
      alert('Please enter a valid User Role ID.');
    }
  }
 
  // Clear form fields
  clearForm(): void {
    this.userRole = { userRoleId: 0, roleName: '' };  // Clear roleName and userRoleId
  }

  showForm(action: string): void {
    this.currentAction = action;  // Set the current action based on the button clicked
    if (action === 'getAll') {
      this.getAllUserRoles();  // Fetch all user roles when the "List of All User Roles" is selected
    } else if (action === 'getById' && this.userRole.userRoleId) {
      this.getUserRoleById(this.userRole.userRoleId);  // Fetch user role by ID if available
    } else {
      this.clearForm();  // Clear the form for other actions
    }
  }
}
 
 