import { Component } from "@angular/core";
import { AttachmentService } from "./attachment.service";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { AttachmentProjection, Attachment } from "../../models/attachment.model";

@Component({
  selector: "attachment-crud",
  templateUrl: "./attachment.component.html",
  standalone: true,
  imports: [CommonModule, FormsModule],
  providers: [AttachmentService]
})
export class AttachmentComponent {
  // Attachment object to bind form data
  attachment: Attachment = {
    attachmentId: 0,
    fileName: "",
    filePath: "",
    task: { taskId: 0 }
  };

  // List of attachments to display in the table
  attachmentList: AttachmentProjection[] = [];

  // User feedback message
  message: string = "";

  // Action selected by the user
  selectedAction: string = "";

  constructor(private attachmentService: AttachmentService) {}

  // Handle action selection from buttons
  selectAction(action: string): void {
    this.selectedAction = action;
    this.clearForm(); // Reset form when changing actions
    this.message = "";
  }

  // Form submission handler
  onFormSubmit(): void {
    switch (this.selectedAction) {
      case "create":
        this.uploadNewAttachment();
        break;
      case "update":
        this.updateAttachmentDetails();
        break;
      case "getById":
        this.getAttachmentById();
        break;
      case "delete":
        this.deleteAttachment();
        break;
      default:
        this.message = "Please select a valid action.";
    }
  }

  // Upload a new attachment
  private uploadNewAttachment(): void {
    this.attachmentService.uploadNewAttachment(this.attachment).subscribe({
      next: (response: string) => {
        // 'response' now contains the success message from the backend
        this.message = response; // Display the success message
        console.log("Response from server:", response); // Log the server response for debugging

        this.clearForm(); // Clear the form
      },
      error: (err) => {
        console.error("Error uploading attachment:", err); // Log the error for debugging
        this.message = `Error uploading attachment: ${err.message}`;
      }
    });
  }

  // Update an existing attachment
  private updateAttachmentDetails(): void {
    if (!this.attachment.attachmentId) {
      this.message = "Attachment ID is required for update.";
      return;
    }
    this.attachmentService.updateAttachmentDetails(this.attachment).subscribe({
      next: () => {
        this.message = "Attachment updated successfully!";
        this.clearForm();
      },
      error: (err) => (this.message = `Error updating attachment: ${err.message}`)
    });
  }

  // Get a specific attachment by ID
  private getAttachmentById(): void {
    if (!this.attachment.attachmentId) {
      this.message = "Attachment ID is required.";
      return;
    }

    this.attachmentService.getAttachmentById(this.attachment.attachmentId).subscribe(
      (data) => {
        // Wrap the fetched attachment in an array for display consistency
        this.attachmentList = [data];
        this.message = "Attachment fetched successfully!";
      },
      (error) => {
        console.error("Error fetching attachment by ID:", error.message);
        this.message = "Failed to fetch attachment: " + error.message;
      }
    );
  }

  // Delete an attachment
  public deleteAttachment(): void {
    if (!this.attachment.attachmentId) {
      this.message = "Attachment ID is required.";
      return;
    }
    this.attachmentService.deleteAttachment(this.attachment.attachmentId).subscribe(
      () => {
        this.clearForm();
        this.message = "Attachment deleted successfully!";
      },
      (error) => {
        console.error("Error deleting attachment:", error.message);
        this.message = "Failed to delete attachment: " + error.message;
      }
    );
  }

  // Fetch all attachments
  public getListOfAllAttachments(): void {
    this.attachmentService.getListOfAllAttachment().subscribe({
      next: (data) => {
        this.attachmentList = data;
        this.message = "All attachments fetched successfully!";
      },
      error: (err) => (this.message = `Error fetching attachments: ${err.message}`)
    });
  }

  // Clear the form
  private clearForm(): void {
    this.attachment = {
      attachmentId: 0,
      fileName: "",
      filePath: "",
      task: { taskId: 0 }
    };
  }

  // Disable submit button based on selected action
  public isSubmitDisabled(): boolean {
    if (this.selectedAction === "create" || this.selectedAction === "update") {
      return !this.attachment.fileName || !this.attachment.filePath || !this.attachment.task.taskId;
    }
    if (this.selectedAction === "getById" || this.selectedAction === "delete") {
      return !this.attachment.attachmentId;
    }
    return true;
  }
}
