import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { Attachment, AttachmentProjection } from "../../models/attachment.model";

@Injectable({
  providedIn: "root"
})
export class AttachmentService {
  private static url: string = "http://localhost:8091/api/attachments";

  constructor(private httpClient: HttpClient) {}

  // Get the list of all attachments - Returns AttachmentProjection[]
  public getListOfAllAttachment(): Observable<AttachmentProjection[]> {
    return this.httpClient.get<AttachmentProjection[]>(`${AttachmentService.url}/all`);
  }

  public uploadNewAttachment(attachment: Attachment): Observable<string> {
    return this.httpClient.post<string>(`${AttachmentService.url}/post`, attachment, {
      responseType: 'text' as 'json' // Explicitly handle plain text response
    });
  }

  // Get attachment by ID - Returns AttachmentProjection
  public getAttachmentById(attachmentId: number): Observable<AttachmentProjection> {
    return this.httpClient.get<AttachmentProjection>(`${AttachmentService.url}/${attachmentId}`);
  }

  // Update attachment details - Takes Attachment and Returns Attachment
  public updateAttachmentDetails(attachment: Attachment): Observable<Attachment> {
    return this.httpClient.put<Attachment>(`${AttachmentService.url}/update/${attachment.attachmentId}`, attachment);
  }

  // Delete attachment by ID - Returns any (status or success message)
  public deleteAttachment(attachmentId: number): Observable<void> {
    return this.httpClient.delete<void>(
      `${AttachmentService.url}/delete/${attachmentId}`
    );
  }
}
