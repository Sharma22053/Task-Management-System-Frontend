 import { Component, OnInit } from "@angular/core";
import { TaskCategoryService } from "./taskcategory.service";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
 
@Component({
  selector: 'app-taskcategory',
  templateUrl: './taskcategory.component.html',
  standalone: true,
  imports: [CommonModule, FormsModule],
  providers: [TaskCategoryService],
})
export class TaskCategoryComponent {
  taskCategory: any = { taskId: 0, categoryIds: [] }; // Task and associated categories
  taskId: number = 0; // For fetching categories by task ID
  categoryId: number = 0; // For fetching tasks by category ID
  categoryList: any[] = []; // To store categories for a task
  taskList: any[] = []; // To store tasks for a category
  loading: boolean = false;
  activeSection: string = '';
 
  constructor(private taskCategoryService: TaskCategoryService) {}
 
  ngOnInit() {}
 
  // Associate task with categories
  public associateTaskWithCategories() {
    if (this.taskCategory.taskId && this.taskCategory.categoryIds.length) {
      this.loading = true;
 
      // Adjust taskCategory object to match the expected backend structure
      const taskCategoryRequest = {
        id: {
          taskId: this.taskCategory.taskId,
          categoryId: this.taskCategory.categoryIds[0],  // Assuming the first categoryId is used
        },
        task: {
          taskId: this.taskCategory.taskId,
        },
        category: {
          categoryId: this.taskCategory.categoryIds[0], // Same as above
        }
      };
 
      this.taskCategoryService.associateTaskWithCategories(taskCategoryRequest).subscribe(
        (response) => {
          console.log("Task associated with categories:", response);
          this.clearForm();
          this.loading = false;
        },
        (error) => {
          this.loading = false;
          console.error("Error associating task with categories:", error);
          alert("Error associating task with categories. Please try again.");
        }
      );
    } else {
      alert("Please provide a valid task ID and categories.");
    }
  }
 
 
  // Get categories for a specific task
  public getCategoriesForTask() {
    if (this.taskId > 0) {
      this.loading = true;
 
      this.taskCategoryService.getCategoriesByTaskId(this.taskId).subscribe(
        (data) => {
          this.categoryList = data;
          this.loading = false;
        },
        (error) => {
          this.loading = false;
          console.error("Error fetching categories for task:", error);
          alert("Error fetching categories. Please try again.");
        }
      );
    } else {
      alert("Please enter a valid task ID.");
    }
  }
 
  // Get tasks for a specific category
  public getTasksForCategory() {
    if (this.categoryId > 0) {
      this.loading = true;
 
      this.taskCategoryService.getTasksByCategoryId(this.categoryId).subscribe(
        (data) => {
          this.taskList = data;
          this.loading = false;
        },
        (error) => {
          this.loading = false;
          console.error("Error fetching tasks for category:", error);
          alert("Error fetching tasks. Please try again.");
        }
      );
    } else {
      alert("Please enter a valid category ID.");
    }
  }
 
  toggleSection(section: string): void {
    this.activeSection = this.activeSection === section ? '' : section;
  }
  
  // Clear the form after operation
  private clearForm() {
    this.taskCategory = { taskId: 0, categoryIds: [] };
    this.taskId = 0;
    this.categoryId = 0;
    this.categoryList = [];
    this.taskList = [];
  }
}
 
 