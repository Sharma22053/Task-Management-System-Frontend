import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { CategoryService } from './category.service';
import { Category , CategoryProjection } from '../../models/category.model';
import { map } from 'rxjs';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  standalone: true,
  imports: [CommonModule, FormsModule],
  providers: [CategoryService]
})
export class CategoryComponent {
  categories: CategoryProjection[] = [];
  categoryTaskCount: Map<string, number> = new Map();
  selectedCategory: Category = { categoryId: 0, categoryName: '' };
  newCategory: Category = { categoryId: 0, categoryName: '' };
  isEditing = false;
  currentAction: string = '';

  constructor(private categoryService: CategoryService) {}


  loadAllCategories(): void {
    this.categoryService.getAllCategories().subscribe((data) => {
      if (data && data.length > 0) {
        this.categories = data;
      } else {
        alert('No categories found.');
      }
    }, error => {
      console.error('Error fetching categories:', error);
      alert('Failed to load categories.');
    });
  }
  

  //get category by categoryID
    loadCategoryById(): void {
        if (!this.newCategory.categoryId) {
          alert('Please enter a valid Category ID.');
          return;
        }
      
        this.categoryService.getCategoryById(this.newCategory.categoryId).subscribe({
          next: (data) => {
            console.log('Category fetched by ID:', data);  // Check the data
            this.categories = [data]; // Wrap in an array to display in the table
            this.currentAction = 'getById'; // Ensure table visibility
            
          },
          error: (err) => {
            console.error('Error fetching category by ID:', err);
            alert('Failed to fetch the category. Please check the ID and try again.');
          }
        });
      }
      
  

  // Load category task counts
  // Convert Map to Object for keyvalue pipe compatibility
// convertMapToObject(map: Map<string, number>): { [key: string]: number } {
//     const obj: { [key: string]: number } = {};
//     map.forEach((value, key) => {
//       obj[key] = value;
//     });
//     return obj;
//   }
  
  // Load category task counts
  loadCategoryTaskCounts(): void {
    this.categoryService.getCategoriesWithTaskCount().subscribe((data) => {
      console.log('Category Task Count:', data);  // Log data to check the structure
      // Convert Map to Object
      this.categoryTaskCount = new Map(Object.entries(data));
    }, error => {
      console.error('Error fetching category task counts:', error);
      alert('Failed to load category task counts.');
    });
  }
  
  // Add a new category
  addCategory(): void {
    this.categoryService.createCategory(this.newCategory).subscribe((response) => {
      console.log(response);
      this.loadAllCategories(); // Refresh the list
      this.newCategory = { categoryId: 0, categoryName: '' };
    });
  }

  // Select a category for editing
  editCategory(category: Category): void {
    this.selectedCategory = { ...category };
    this.isEditing = true;
  }

  // Update a category
  updateCategory(): void {
    if (!this.newCategory.categoryId || !this.newCategory.categoryName) {
      alert('Please provide both a valid Category ID and Category Name.');
      return;
    }
  
    this.categoryService
      .updateCategory(this.newCategory.categoryId, { categoryName: this.newCategory.categoryName })
      .subscribe({
        next: (response) => {
          console.log('Category updated successfully:', response);
          this.loadAllCategories(); // Refresh the list
          this.newCategory = { categoryId: 0, categoryName: '' }; // Reset form inputs
          alert('Category updated successfully.');
        },
        error: (err) => {
          console.error('Error updating category:', err);
          alert('Failed to update the category. Please try again.');
        }
      });
  }
  
  
  

  // Delete a category
  deleteCategory(categoryId: number): void {
    this.categoryService.deleteCategory(categoryId).subscribe((response) => {
      console.log(response);
      this.loadAllCategories(); // Refresh the list
    });
  }

  // Show the appropriate form based on action
showForm(action: string): void {
  this.currentAction = action;
  this.newCategory = { categoryId: 0, categoryName: '' }; // Reset form inputs
  this.categories = []; // Reset table
  this.categoryTaskCount = new Map(); // Reset task count map
  
  if (action === 'getAll') {
    this.loadAllCategories(); // Load all categories when the "List of All Categories" button is clicked
  } else if (action === 'getTaskCount') {
    this.loadCategoryTaskCounts(); // Load task counts when the "Categories with Task Count" button is clicked
  }
}

}
