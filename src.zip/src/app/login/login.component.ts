import { Component } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";


@Component({
  selector: 'login-root',
  templateUrl: './login.component.html',
  standalone: true,
  imports: [CommonModule, FormsModule],
  providers: []
})
export class LoginComponent {
    username: string = '';
  password: string = '';
  selectedRole: string | null = null;
  roleError: boolean = false;

  onLogin(): void {
    if (!this.selectedRole) {
      this.roleError = true;
    } else {
      this.roleError = false;
      // Perform login logic here
      console.log('Username:', this.username);
      console.log('Password:', this.password);
      console.log('Role:', this.selectedRole);
    }
  }
}
